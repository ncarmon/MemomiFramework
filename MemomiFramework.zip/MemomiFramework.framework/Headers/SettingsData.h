//
//  SettingsData.h
//  Strauss
//
//  Created by Lior Shabo on 3/30/15.
//  Copyright (c) 2015 Cpart LTD. All rights reserved.
//

#import <JSONModel/JSONModel.h>
#import <Foundation/Foundation.h>
#import "KeyValueData.h"


@interface SettingsData : JSONModel

@property(nonatomic,strong) NSMutableArray<KeyValueData,Optional> *items;

- (id)initWithArray:(NSArray*)array;
- (NSString*)getKeyValue:(NSString*)key;

@end
