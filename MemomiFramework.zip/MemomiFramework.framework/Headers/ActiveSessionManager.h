//
//  ActiveSessionManager.h
//  Strauss
//
//  Created by Lior Shabo on 3/5/15.
//  Copyright (c) 2015 Cpart LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "Constant.h"
#import "SettingsData.h"

#define kApplog @"kApplog"

#define NOTIFICATION_LIPS_CHANGED (@"LipsNotification")
#define NOTIFICATION_EYES_BOTTOM_CHANGED (@"EyesBottomNotification")
#define NOTIFICATION_EYES_TOP_CHANGED (@"EyesTopNotification")
#define NOTIFICATION_LOOKS_CHANGED (@"LooksNotification")

#define NOTIFICATION_CHEEKS_CHANGED (@"CheeksNotification")
#define NOTIFICATION_MAKEUP_CHANGED (@"MakeupNotification")


#define kDeviceUDIDKey @"kDeviceUDIDKey"
#define kBaseUrlKey @"baseUrl"

extern NSString* const MintServerURLChangedNotification;

@interface ActiveSessionConfiguration : NSObject

@property(nonatomic,retain) SettingsData *settings;

@property(nonatomic,assign) double syncPoolingInMinutes;
@property(nonatomic,assign) double timeBetweenSyncInMinutes;

@end

@interface ActiveSessionManager : NSObject

@property(nonatomic,strong) ActiveSessionConfiguration *configuration;
@property(nonatomic,strong) NSString *baseURL;
@property(nonatomic,assign,getter = getDeveloperModeOn) BOOL developerModeOn;

@property(nonatomic,strong) NSMutableArray *logArray;

+(ActiveSessionManager*) getInstance;
- (BOOL)isProductionEnvironment;
- (void)changeServer;

- (void)appendToLog:(NSString*)log info:(NSString*)info;
- (void)appendToLog:(NSString*)log;

+ (void)generateDeviceUDID;

@end

