//
//  KeyValueData.h
//  Strauss
//
//  Created by Lior Shabo on 3/5/15.
//  Copyright (c) 2015 Cpart LTD. All rights reserved.
//

#import <JSONModel/JSONModel.h>
#import <Foundation/Foundation.h>

@protocol KeyValueData <NSObject>
@end

@interface KeyValueData : JSONModel

@property(nonatomic,strong) NSString<Optional> *key;
@property(nonatomic,strong) NSString<Optional> *value;

@property (nonatomic, assign) BOOL isSelected;

@end
