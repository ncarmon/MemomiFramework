//
//  UIFont+Dynamic.h
//  Strauss
//
//  Created by Lior Shabo on 8/5/15.
//  Copyright (c) 2015 Cpart LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFont (Dynamic)

+(UIFont *)appBoldCondensedFontWithStyle:(NSString *)style size:(float)size;
+(UIFont *)appMediumFontWithStyle:(NSString *)style size:(float)size;
+(UIFont *)appSemiBoldFontWithStyle:(NSString *)style size:(float)size;
+(UIFont *)appCondensedFontWithStyle:(NSString *)style size:(float)size;
+(UIFont *)appBookFontWithStyle:(NSString *)style size:(float)size;
+(UIFont *)appAlmoniDLAAAFontWithStyle:(NSString *)style size:(float)size;
+(UIFont *)appAlmoniDLAAABoldFontWithStyle:(NSString *)style size:(float)size;

@end
