//
//  MemomiMakeup.h
//  MemomiMakeup
//
//  Created by Nava Carmon on 2/5/19.
//  Copyright © 2019 Memomi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MemomiMakeup.
FOUNDATION_EXPORT double MemomiMakeupVersionNumber;

//! Project version string for MemomiMakeup.
FOUNDATION_EXPORT const unsigned char MemomiMakeupVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MemomiMakeup/PublicHeader.h>



