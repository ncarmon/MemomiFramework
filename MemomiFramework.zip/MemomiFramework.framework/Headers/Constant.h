//
//  Constant.h
//  Strauss
//
//  Created by Lior Shabo on 3/5/15.
//  Copyright (c) 2015 Cpart LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kThisVersionNumber      @"versionNumber"
#define kBuildNumber            @"buildNumber"

//#define SERVICE_URL @"https://s3-us-west-2.amazonaws.com"
#define SERVICE_URL @"https://mmshare1.blob.core.windows.net"
#if TARGET_IPHONE_SIMULATOR
#define IS_SIMULATOR 1
#else
#define IS_SIMULATOR 0
#endif

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)
