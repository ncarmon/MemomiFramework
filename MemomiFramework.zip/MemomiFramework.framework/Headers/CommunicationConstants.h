//
//  CommunicationConstants.h
//

// Services
// https://mmshare1.blob.core.windows.net/storage/Samsclub/Glasses/iOSGlasses.json
#define kSettingsAllServiceName @""
#define kSyncDataServiceName @"memomi-data/iOSProducts.json"
#define kSyncDataServiceNameWithLooks @"memomi-data/iOS_Files/"
#define kSyncDataServiceNameWithFlows @"memomi-assets-files/Flow/"
#define kSyncDataServiceNameWithGlasses @"storage/Samsclub/Glasses/"
#define kSyncDataProductsFileName @"iOSProductsLooks.json"
#define kSyncDataFlowFileName @"FlowiOS_Calibrate.json"
#define kSyncDataGlassesFileName @"iOSGlasses.json"


typedef NS_ENUM(NSInteger, WebServiceType) {
    kSettingsAll = 0,
    kSyncData = 1,
};
