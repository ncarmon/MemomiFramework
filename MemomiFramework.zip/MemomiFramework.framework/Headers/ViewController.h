
/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller for camera interface
 */


#import <UIKit/UIKit.h>

@class ProductObject;

@interface ViewController : UIViewController {

/**
 * Timer for periodically refreshing of the results display.
 *
 */
NSTimer *resultsDisplayTimer;

/**
 * Label for FPS display.
 *
 */
IBOutlet UILabel *fpsLabel;

/**
 * Label for tracker status display.
 *
 */
IBOutlet UILabel *statusLabel;

/**
 * Label for tracker information display.
 *
 */
IBOutlet UILabel *infoLabel;

/**
 * Image picker for selectiong video file from album.
 *
 */
UIImagePickerController *imgPicker;
    
}

@property (nonatomic, retain) UIImage *trackImage;
@property (nonatomic, retain) NSTimer *resultsDisplayTimer;

@property (nonatomic, retain) IBOutlet UIView *infoContainer;
@property (nonatomic, retain) IBOutlet UIView *cameraSettingsContainer;
@property (nonatomic, retain) IBOutlet UILabel *fpsLabel;
@property (nonatomic, retain) IBOutlet UILabel *statusLabel;
@property (nonatomic, retain) IBOutlet UILabel *infoLabel;

@property (nonatomic, retain) UIImagePickerController *imgPicker;
@property (nonatomic, retain) IBOutlet UIButton *btnTakePic;
@property (nonatomic, retain) IBOutlet UIButton *btnTakeVideo;
@property (nonatomic, retain) IBOutlet UIButton *btnSettings;
@property (nonatomic, retain) IBOutlet UIButton *btnReset;
@property (nonatomic, retain) IBOutlet UISlider *exposeSlider;
@property (nonatomic, retain) IBOutlet UISlider *amountSlider;

@property (nonatomic, retain) IBOutlet NSLayoutConstraint *containerHeightConstraint;

@property (nonatomic, retain) IBOutlet NSLayoutConstraint *photoButtonWidthConstraint;
@property (nonatomic, retain) IBOutlet NSLayoutConstraint *photoButtonHeightConstraint;
@property (nonatomic, retain) IBOutlet NSLayoutConstraint *videoButtonWidthConstraint;
@property (nonatomic, retain) IBOutlet NSLayoutConstraint *videoButtonHeightConstraint;

@property (nonatomic, retain) IBOutlet NSLayoutConstraint *resetButtonWidthConstraint;
@property (nonatomic, retain) IBOutlet NSLayoutConstraint *resetButtonHeightConstraint;
@property (nonatomic, retain) IBOutlet NSLayoutConstraint *settingsButtonWidthConstraint;
@property (nonatomic, retain) IBOutlet NSLayoutConstraint *settingsButtonHeightConstraint;

@property (nonatomic, retain) IBOutlet NSLayoutConstraint *exposeSliderVerticalConstraint;
@property (nonatomic, retain) IBOutlet NSLayoutConstraint *amountSliderVerticalConstraint;

@property (nonatomic, retain) IBOutlet UIView *calibrationView;

@property (nonatomic, retain) IBOutlet UISlider *scaleX;
@property (nonatomic, retain) IBOutlet UISlider *scaleY;
@property (nonatomic, retain) IBOutlet UISlider *scaleZ;

@property (nonatomic, retain) IBOutlet UISlider *translationX;
@property (nonatomic, retain) IBOutlet UISlider *translationY;
@property (nonatomic, retain) IBOutlet UISlider *translationZ;

@property (nonatomic, retain) IBOutlet UISlider *rotationX;
@property (nonatomic, retain) IBOutlet UISlider *rotationY;
@property (nonatomic, retain) IBOutlet UISlider *rotationZ;

@property (nonatomic, retain) IBOutlet UILabel *scaleLabelX;
@property (nonatomic, retain) IBOutlet UILabel *scaleLabelY;
@property (nonatomic, retain) IBOutlet UILabel *scaleLabelZ;

@property (nonatomic, retain) IBOutlet UILabel *translationLabelX;
@property (nonatomic, retain) IBOutlet UILabel *translationLabelY;
@property (nonatomic, retain) IBOutlet UILabel *translationLabelZ;

@property (nonatomic, retain) IBOutlet UILabel *rotationLabelX;
@property (nonatomic, retain) IBOutlet UILabel *rotationLabelY;
@property (nonatomic, retain) IBOutlet UILabel *rotationLabelZ;


-(IBAction) sliderValueChanged:(UISlider *) sender;
/**
 * Method for starting tracking from a video.
 *
 */
-(IBAction)trackVideoAction:(id)sender;
/**
 * Method for startig tracking from an image.
 *
 */
-(IBAction)trackImageAction:(id)sender;
/**
 * Method for startig tracking from a camera.
 *
 */
-(IBAction)trackCameraAction:(id)sender;
/**
 * Method for stopinig tracking.
 *
 */
-(IBAction)trackStopAction:(id)sender;
/**
 * Method for quitting app.
 *
 */
-(IBAction)trackQuitAction:(id)sender;
/**
 * Method used for creating and initializing a new informer.
 */
- (IBAction)focusAndExposeTap:(UIGestureRecognizer *)gestureRecognizer;
-(void) applyProductObject:(ProductObject *) object;
-(UIImage *) getImage;
- (void)applyObjectIndex:(NSInteger) index;
- (void) setCurrentProductObject:(ProductObject *) object index:(NSInteger)index;
-(void) cleanCurrentProductObject;
@end
