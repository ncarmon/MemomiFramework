//
//  ZaparootService.h
//
//
//  Created by lior on 17/12/13.
//
//

#import <Foundation/Foundation.h>
#import "CommunicationConstants.h"

#define CANCEL_ERROR_CODE -1111

@interface MintNetworkService : NSObject

typedef void (^successService)(NSURLResponse *service, id responseObject);
typedef void (^failedService)(NSURLResponse *service, NSString *error, int code);

+ (MintNetworkService*)sharedService;

- (NSURLSessionDataTask*)settingsGetAll:(successService)success failure:(failedService)failure;
- (NSURLSessionDataTask*)getFullSyncData:(successService)success failure:(failedService)failure;

@end

