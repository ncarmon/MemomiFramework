//
//  UIColor+Extension.h
//  MySuperMarketIOSApp
//
//  Created by Lior-MacbookPro on 11/27/14.
//  Copyright (c) 2014 mysupermarket. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Extension)

+ (UIColor *)colorFromHexString:(NSString *)hexString;
+ (UIColor *)colorFromHexWithAlphaString:(NSString *)hexString;
- (UIColor *)darkerColor;
- (UIColor *)lighterColor;

@end
